# -*- coding:utf-8 -*-
'''
Created on 2019年03月10日

@author: yulei
'''
import os
MERCHANT_NUM = 'etcp'  # ETCP
MERCHANT_KEY = 'etcp_key'  # ETCP
# MERCHANT_NUM = 'ccic'  # ETCP
# MERCHANT_KEY = 'ccic_key'  # ETCP

picture_rootpath = r'C:\Users\Public\Pictures\Sample Pictures' + '\\'
root_path = os.path.split(os.path.split(os.path.realpath(__file__))[0])[0]
case_path = root_path + '\\cases'
temp_path = root_path + '\\result\\run.txt'
log_path = root_path + '\\result'
db_dict = {
    'lot': ['rw.cityplatform_qa.mysql.etcp.cn', 'cityplatform_rw', 'i+BFhuH2pcYXafu+pbHpxTpjHp4=', '3326', 'cityplatform']
}
JsonArray = {
    #旧标准中需要的格式，新标准就一个lots，新标准中rateDesc不为jsonarray
    'lots': ['parkingLotNo', 'lastSpace', 'totalSpace'],#旧标准
    # 'lots': ['parkingLotThirdNo', 'lastSpace', 'totalSpace'],#新标准
    'outlines': ['subShortName', 'outlineId', 'parkType', 'parkLocation', 'points'],
    'passageWay': ['id', 'lat', 'lon', 'type'],
    'areaSpaces': ['parkingSpaceNo', 'parkingSpaceName'],
    'rateDesc': ['rateDesc', 'dayTopPrice'],#新标准无此项
}
int_list = [
    'parkingLotType',
    'isSupportShare',
    'isSupportTelectronicInvoice',
    'isSupportElePay',
    'isUse',
    'parkingSpaceNum',
    'totalChargePlace',
    'freeTime',
    'dayTopPrice',
    'lastSpace',
    'totalSpace',
    'parkingType',
    'parkingTotalAmount',
    'parkingTime',
    'type',
    'amount',
    'paySubChannel',
    'spaceType',
    'unitPrice',
    'spaceFree',
]
time_list = [
    "time",
    "inTime",
    "outTime",
    "payTime",
    'reserveOrderTime',
    'reserveStartTime',
    'reserveEndTime',
    'stateChangeTime',
    'busiTime',
    'effectiveTime',
    'syncTime',
    "openTime",
    "startTime",
    "endTime",
    "effectiveTime",
]
GET = [
    "orderunpay",
    "orderhistory",
    "couponlist",
    # "service/cjt/getParkingFee",
]
TESTOBJ = {
#旧标准云平台接口
    #本地mock测试
    "CancelReserve/": (
        'Yulei',
        'reserveOrderNo',
    ),
    #基础数据同步
    "parking/lot/lotin": (
        'parkingLotThirdNo',
        'parkingLotName',
        'lotShortName',
        'cityNo',
        'areaNo',
        'address',
        'parkingLotType',
        'isSupportShare',
        'isSupportTelectronicInvoice',
        'isSupportElePay',
        'isUse',
        'longitude',
        'latitude',
        'parkingSpaceNum',
        'totalChargePlace',
        'busiTime',
        'freeTime',
        'groundType',
        # 'parkingMobile',#
        # 'ein',#
        # 'isAutoWithhold',#
        # 'isSupportInsidePay',#
        # 'roughRate',#
        # 'outlines',#
        # 'passageWay',#
        # 'rateDesc',#
    ),
    #基础数据更新
    "parking/lot/lotupdate": (
        'parkingLotNo',
        'parkingLotName',#
        'lotShortName',
        'cityNo',
        'areaNo',
        'address',
        'parkingLotType',
        'isSupportShare',
        'isSupportTelectronicInvoice',
        'isSupportElePay',
        'isUse',
        'longitude',
        'latitude',
        'parkingSpaceNum',
        'totalChargePlace',
        'busiTime',
        'freeTime',
        'groundType',
        'parkingMobile',#
        'ein',#
        'isAutoWithhold',#
        'isSupportInsidePay',#
        'roughRate',#
        'outlines',#
        'passageWay',#
        'rateDesc',#
    ),
    #动态数据同步
    "parking/lot/dynamic/update": (
        'syncTime',
        'lots',
    ),
    # "parkingLot/logic/inParkingLot": (
    #     'parkingLotNo',
    #     'parkingRecordNo',
    #     'plateNumber',
    #     'plateColor',
    #     'parkingType',
    #     'reserveOrderNo',
    #     'inTime',
    #     # 'inBrakeName',
    #     # 'inBrakeId',
    #     # 'remarks',
    # ),
    #入场通知
     "parkingLot/logic/inParkingLot": (
        'parkingLotNo',
        'parkingRecordNo',
        'plateNumber',
        'plateColor',
        'inTime',
        'inBrakeName',#
        'inBrakeId',#
        'remarks',#
    ),
    #出场通知
    "parkingLot/logic/outParkingLot": (
        'parkingLotNo',
        'parkingRecordNo',
        'plateNumber',
        'outTime',
        'parkingType',
        'parkingTotalAmount',
        'parkingTime',
        # 'reserveOrderNo',#
        'outBrakeName',#
        'outBrakeId',#
        'remarks',#
    ),
    # "parkingLot/logic/outParkingLot": (
    #     'parkingLotNo',
    #     'parkingRecordNo',
    #     'plateNumber',
    #     'outTime',
    #     'parkingTotalAmount',
    #     'parkingTime',
    #     'outBrakeName',
    #     'outBrakeId',
    #     'remarks',
    # ),
    #上传图片
    "parkingLot/logic/uploadImg":(
        'parkingLotNo',
        'type',
        'thirdParkingRecordNo',
        'img',
    ),
    #主动支付完成通知
    "notify/1/notify4ParkingIsv": (
        'parkingRecordNo',
        'transactionNo',
        'payNo',
        'amount',
        'payTime',
        'paySubChannel',
    ),
    #开票通知
    "invoice/invoiceNotice": (
        'noticeNo',
        'openStatus',
        'invoiceHead',#
        'invoiceAmount',#
        'invoiceNo',#
        'openTime',#
        'invoiceContent',#
    ),
    # "parking/share/lot/sharein": (
    #     'parkingLotNo',
    #     'shareLinkPhone',
    #     'spaces',
    # ),
    #共享车位数据同步
    "parking/share/lot/lotspace/in": (
        'parkingLotNo',
        'shareLinkPhone',
        'parkingSpaceThirdNo',
        'parkingSpaceName',
        'floor',
        'spaceType',
        'regionNo',
        'regionName',
        'isUse',
        'groundLockNo',#
        'bluetoothSn',#
    ),
    #共享车场数据更新
    "parking/share/lot/lotspace/update": (
        'parkingLotNo',
        'shareLinkPhone',
        'parkingSpaceNo',
        'parkingSpaceName',
        'floor',
        'spaceType',
        'regionNo',
        'regionName',
        'isUse',
        'groundLockNo',
        'bluetoothSn',
    ),
    # "parking/share/lot/shareupdate": (
    #     'parkingLotNo',
    #     'shareLinkPhone',
    #     'spaces',
    # ),
    #车场发布通知
    "parking/share/release/syncArea": (
        'releaseThirdNo',
        'parkingLotNo',
        'regionNo',
        'areaSpaces',
        'unitPrice',
        'startTime',
        'endTime',
        'effectiveTime',
        'syncTime',
    ),
    # "service/cjt/reserveParkLot": (
    #     'parkingLotNo',
    #     'reserveOrderNo',
    #     'reserveOrderTime',
    #     'reserveStartTime',
    #     'reserveEndTime',
    #     'reserveSpaceNo',
    #     'reservePlateNumber',
    # ),
    # "取消预约通知":(
    #     'reserveOrderNo',
    # ),
    #根据预约单号查询预约信息
    "parking/share/reserve/info": (
        'reserveOrderNo',
    ),
    # "service/jc/status": (
    #     'parkingLotNo',
    #     'parkingSpaceNo',
    # ),
    #车位状态同步
    "parking/share/space/syncState":(
        'parkingLotNo',
        'spaceType',
        'spaceFree',
        'stateChangeTime',
        'parkingSpaceNo',#
        'regionNo',#
        'plateNumber',#
        'groundLockNo',#
    ),
#服务商接口
    #停车费查询
    "service/cjt/getParkingFee": (
        'plateNumber',
    ),
    #主动支付
    "service/cjt/prePay": (
        'parkingRecordNo',
        'payNo',
        'amount',
        'subject',
        'notifyUrl',
        'returnUrl',
    ),
    #主动支付查询
    "service/cjt/queryOrderStatus": (
        'parkingRecordNo',
        'payNo',
    ),
#新标准接口
    #车场数据同步/变更，变更只有一个车场编号是必填，其余都是非必填
    "saas/parking/lot/lot": (
        'parkingLotThirdNo',
        'parkingLotName',
        'lotShortName',
        'cityNo',
        'areaNo',
        'address',
        'parkingLotType',
        'isSupportShare',
        'isSupportTelectronicInvoice',
        'isSupportElePay',
        'isUse',
        'longitude',
        'latitude',
        'parkingSpaceNum',
        'totalChargePlace',
        'busiTime',
        'freeTime',
        'groundType',
        'parkingMobile',#
        'ein',#
        'isAutoWithhold',#
        'isSupportInsidePay',#
        'roughRate',#
        'rateDesc',#
        'dayTopPrice',#
    ),
    #车场数据动态同步
    "saas/parking/lot/dynamic/update": (
        'syncTime',
        'lots',
    ),
    #入场通知
    "saas/parkingLot/logic/inParkingLot": (
        'parkingLotThirdNo',
        'parkingRecordNo',
        'plateNumber',
        'plateColor',
        'time',
        'brakeName',#
        'brakeId',#
        'remarks',#
    ),
    #出场通知
    "saas/parkingLot/logic/outParkingLot": (
        'parkingLotThirdNo',
        'parkingRecordNo',
        'plateNumber',
        'time',
        'parkingType',
        'parkingTotalAmount',
        'parkingTime',
        # 'reserveOrderNo',#
        'brakeName',#
        'brakeId',#
        'remarks',#
    ),
    #图片上传
    "saas/parkingLot/logic/uploadImg": (
        'parkingLotThirdNo',
        'type',
        'parkingRecordNo',
        'img',
    ),
    #开票结果通知-与旧标准保持不变
    #共享车位新增同步
    # "saas/parking/share/lotSpace/lotSpace": (
    #     'parkingLotThirdNo',
    #     'parkingSpaceName',
    #     'spaceType',
    #     'isUse',
    #     'parkingSpaceThirdNo',#
    #     'shareLinkPhone',#
    #     'floor',#
    #     'groundLockNo',#
    #     'bluetoothSn',#
    #     'regionNo',#
    #     'regionName',#
    # ),
    #共享车位变更同步
    "saas/parking/share/lotSpace/lotSpace": (
        'parkingSpaceNo',
        'parkingSpaceName',#
        'spaceType',#
        'isUse',#
        'shareLinkPhone',#
        'floor',#
        'groundLockNo',#
        'bluetoothSn',#
        'regionNo',#
        'regionName',#
    ),
    #车场区域车位发布
    "saas/parking/share/release/syncArea": (
        'parkingLotThirdNo',
        'regionNo',
        'unitPrice',
        'startTime',
        'endTime',
        'effectiveTime',
    ),
    #车位出入位状态同步
    "saas/parking/share/space/syncState": (
        'parkingLotThirdNo',
        'spaceType',
        'spaceFree',
        'stateChangeTime',
        'parkingSpaceNo',#
        'groundLockNo',#
        # 'regionNo',#
        # 'plateNumber',#
    ),
    #根据预约单号查询预约信息
    "saas/parking/share/reserve/info": (
        'reserveOrderNo',
    ),
}