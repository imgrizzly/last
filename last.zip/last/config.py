# coding:utf-8
'''
Created on 2019年03月10日

@author: yulei
'''
import ConfigParser
from configmore.configset import *


class Config(object):
    def __init__(self):
        self.file_name = temp_path
        self.conf = ConfigParser.ConfigParser()
        self.conf.read(self.file_name)

    def get_sections(self):
        try:
            return self.conf.sections()
        except Exception, e:
            print repr(e)

    def get_options(self, section):
        try:
            return self.conf.options(section)
        except Exception, e:
            print repr(e)

    def get_value(self, section, option):
        try:
            return self.conf.get(section, option)
        except ConfigParser.NoSectionError, e:
            print repr(e)

    def add_newsections(self, section):
        try:
            self.conf.add_section(section)
            self.conf.write(open(self.file_name, 'w'))
            # print section+' write successfully'
        except Exception, e:
            print repr(e)

    def set_value(self, section, option, value):
        try:
            if section not in self.get_sections():
                self.add_newsections(section)
            self.conf.set(section, option, value)
            self.conf.write(open(self.file_name, 'w'))
            # print section+' set {0} value {1} successfully'.format(option,value)
        except Exception, e:
            print repr(e)