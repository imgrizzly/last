# -*- coding:utf8 -*-
import MySQLdb
# from configset import db_dict


# for key in db_dict:
#     host = db_dict[key][0]
#     user = db_dict[key][1]
#     passwd = db_dict[key][2]
#     port = db_dict[key][3]
#     db = db_dict[key][4]
#     db_cn = MySQLdb.connect(host=host, user=user, passwd=passwd, port=port, db=db, charset='utf8')
#
#
# def test_connection():
#     try:
#         db_cn.ping()
#     except:
#         db_cn = MySQLdb.connect(host=host, user=user, passwd=passwd, port=port, db=db, charset='utf8')
#     return db_cn

#
# host = 'rw.cityplatform_qa.mysql.etcp.cn'
# user = 'cityplatform_rw'
# passwd = 'i+BFhuH2pcYXafu+pbHpxTpjHp4='
# port = 3326
# db = 'cityplatform'
# # 打开数据库连接
# # db = MySQLdb.connect("localhost", "root", "123456yl", "etcpdbv_nest_twobest_second", charset='utf8' )
# # db = MySQLdb.connect("10.86.30.36:3306","root","etcp2012etcp2012",charset='utf8')#线上mysql
# db = MySQLdb.connect(host=host, user=user, passwd=passwd, port=port, db=db, charset='utf8')
# # 使用cursor()方法获取操作游标
# cursor = db.cursor()
#
#
# def getdb(field, table, condition, exceptvalue):
#     # 使用execute方法执行SQL语句
#     sql = 'SELECT {0} from {1} where CONTAINS({2},{3})'.format(field, table, condition, exceptvalue)
#     cursor.execute(sql)
#
#     # 使用 fetchone() 方法获取一条数据,返回tuple
#     # data = cursor.fetchone()
#     # 使用fetchall() 返回一个tuple,元素也为tuple
#     data = cursor.fetchall()
#     for i in data:
#         for j in i:
#             print j
#     return j
