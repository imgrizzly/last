# -*- coding:utf-8 -*-
'''
Created on 2019年03月10日

@author: yulei
'''
#import MySQLdb
# data_base = 'etcpdbv_nest_twobest_share'
# db = MySQLdb.connect("localhost", "root", "123456yl", data_base, charset='utf8' )  #测试本地
# cursor = db.cursor()
from Cityplatform.last.configmore.configset import *
import os, sys
sys.path.append(os.path.join(os.path.split(os.path.split(os.path.realpath(__file__))[0])[0], 'configmore'))
from send_url import *
from configset import *


# from config import Config
# config_obj = Config()
# time_list = []
# for key in time_list:
#     if dictdate[key] == 'time':
#         dictdata[key] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())


def judge_jsonrarray(dictdata, field, param_list):
    if dictdata[field]:
        val_list = dictdata[field].replace('>', ',').split('&')
        if val_list != ['']:
            all_list = []
            for i in val_list:
                j = 0
                dict_space = {}
                l_list = i.split(',')
                for m in param_list:
                    # dict_space[m] = int(l_list[j])
                    dict_space[m] = l_list[j]
                    j += 1
                    if j >= len(l_list):
                        break
                # param_list.pop(0)
                all_list.append(dict_space)
                if field == 'rateDesc':
                    dictdata[field] = dict_space
                else:
                    dictdata[field] = all_list
    return dictdata


def judge_time(dictdata, times):
    if dictdata[times]:
        if dictdata[times] == 'time':
            dictdata[times] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    return dictdata


def judge_convert(dictdata, field):
    if dictdata[field]:
        dictdata[field] = int(dictdata[field])
    return dictdata


def load_picture(img_path):
    '''base64加密图片'''
    try:
        if os.path.exists(img_path):
            with open(img_path, 'rb') as f:
                data_base64 = base64.b64encode(f.read())
                img_string = data_base64.decode('utf-8')
                # print img_string
                # print img_path
                return img_string
        else:
            print img_path + 'not exists'
    except Exception, e:
        print repr(e)


def judge_data(dictdata):
    try:
        for dict_key in dictdata.keys():
            if dict_key in int_list:
                judge_convert(dictdata, dict_key)
            elif dict_key in time_list:
                judge_time(dictdata, dict_key)
            elif dict_key in JsonArray.keys():
                judge_jsonrarray(dictdata, dict_key, JsonArray[dict_key])
            elif dict_key == 'img':
                picture_path = picture_rootpath + dictdata['img']
                dictdata['img'] = load_picture(picture_path)
    except Exception, e:
        pass
        # print 'judge error: {}'.format(repr(e))
    finally:
        return dictdata
    # # if dictdata.has_key('lots'):
    # #     if dictdata['syncTime'] == 'time':
    # #         dictdata['syncTime'] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    # #     val_list = dictdata['lots'].replace('>', ',').split('&')
    # #     # print val_list
    # #     if val_list != ['']:
    # #         param_list = ['parkingLotNo', 'lastSpace', 'totalSpace']
    # #         all_list = []
    # #         for i in val_list:
    # #             j = 0
    # #             dict_space = {}
    # #             l_list = i.split(',')
    # #             for m in param_list:
    # #                 dict_space[m] = l_list[j]
    # #                 j += 1
    # #             all_list.append(dict_space)
    # #         dictdata['lots'] = all_list
    # elif dictdata.has_key('outlines'):
    #     val_list = dictdata['outlines'].replace('>', ',').split('&')
    #     if val_list != ['']:
    #         param_list = ['subShortName', 'outlineId', 'parkType', 'parkLocation', 'points']
    #         all_list = []
    #         for i in val_list:
    #             j = 0
    #             dict_space = {}
    #             l_list = i.split(',')
    #             for m in param_list:
    #                 # dict_space[m] = int(l_list[j])
    #                 dict_space[m] = l_list[j]
    #                 j += 1
    #                 if j >= len(l_list):
    #                     break
    #             # param_list.pop(0)
    #             all_list.append(dict_space)
    #         dictdata['outlines'] = all_list
    # elif dictdata.has_key('plateColor'):
    #     # dictdata['plateColor'] = int(dictdata['plateColor'])
    #     # dictdata['remarks'] = int(dictdata['remarks'])
    #     # dictdata['inBrakeName'] = int(dictdata['inBrakeName'])
    #     if dictdata['inTime'] == 'time':
    #         dictdata['inTime'] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    # elif dictdata.has_key('parkingTotalAmount') or dictdata.has_key('parkingTime'):
    #     if dictdata['parkingType']:
    #         dictdata['parkingType'] = int(dictdata['parkingType'])
    #     if dictdata['parkingTotalAmount']:
    #         dictdata['parkingTotalAmount'] = int(dictdata['parkingTotalAmount'])
    #     if dictdata['parkingTime']:
    #         dictdata['parkingTime'] = int(dictdata['parkingTime'])
    #     if dictdata['outTime'] == 'time':
    #         dictdata['outTime'] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    # elif dictdata.has_key('type'):
    #     judge_convert(dictdata, 'type')
    #     # dictdata['type'] = int(dictdata['type'])
    #     # print picture_path
    #     # dictdata['img'] = self.load_picture('C:\Users\Public\Pictures\Sample Pictures\aaa.png')
    #     if dictdata['img']:
    #         picture_path = picture_rootpath + dictdata['img']
    #         dictdata['img'] = load_picture(picture_path)
    # elif dictdata.has_key('paySubChannel'):
    #     # dictdata['amount'] = int(dictdata['amount'])
    #     # dictdata['paySubChannel'] = int(dictdata['paySubChannel'])
    #     if dictdata['payTime'] == 'time':
    #         dictdata['payTime'] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    # elif dictdata.has_key('notifyUrl'):
    #     dictdata['amount'] = int(dictdata['amount'])
    # elif dictdata.has_key('spaces'):
    #     # c='1/2/3&4/5/7/8&x/y&pp/oo'
    #     val_list = dictdata['spaces'].replace('/', ',').split('&')
    #     param_list = ['parkingSpaceNo', 'parkingSpaceName', 'groundLockNo', 'isUse']
    #     all_list = []
    #     for i in val_list:
    #         j = 0
    #         dict_space = {}
    #         l_list = i.split(',')
    #         for m in param_list:
    #             # dict_space[m] = int(l_list[j])
    #             dict_space[m] = l_list[j]
    #             j += 1
    #             if j >= len(l_list):
    #                 break
    #         # param_list.pop(0)
    #         all_list.append(dict_space)
    # elif dictdata.has_key('areaSpaces'):
    #     # c='1/2/3&4/5/7/8&x/y&pp/oo'
    #     val_list = dictdata['areaSpaces'].replace('>', ',').split('&')
    #     if val_list != ['']:
    #         param_list = ['parkingSpaceNo', 'parkingSpaceName']
    #         all_list = []
    #         for i in val_list:
    #             j = 0
    #             dict_space = {}
    #             l_list = i.split(',')
    #             for m in param_list:
    #                 dict_space[m] = l_list[j]
    #                 j += 1
    #             all_list.append(dict_space)
    #         # dictdata['spaces'] = str(all_list)
    #         dictdata['areaSpaces'] = all_list
    #     if dictdata['effectiveTime'] == 'time':
    #         dictdata['effectiveTime'] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    #     if dictdata['syncTime'] == 'time':
    #         dictdata['syncTime'] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())