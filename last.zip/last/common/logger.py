# coding: utf-8
import logging, sys, os
import time
sys.path.append(os.path.join(os.path.split(os.path.split(os.path.realpath(__file__))[0])[0], 'configmore'))
from configset import *


def get_log(logger):
    ne_log = logging.getLogger(logger)
    ne_log.setLevel(logging.INFO)
    find_path = log_path + '\{0}_{1}.log'.format(logger, time.strftime("%Y%m%d", time.localtime()))
    fh = logging.FileHandler(find_path)
    # if ne_log.handlers:
    # if ne_log.handlers!=[]:
    #     ne_log.removeHandler(fh)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    fh.setFormatter(formatter)
    if ne_log.handlers:
        # fh.flush()
        # ne_log.removeHandler(ne_log.handlers)
        ne_log.handlers = []
    ne_log.addHandler(fh)
    return ne_log