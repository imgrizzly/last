# -*- coding: utf-8 -*-
'''
Created on 2019年03月10日

@author: yulei
'''
import time


# from System import *
class Combined(object):
    def __init__(self):
        self.num = 0

    def openFile(self, path):
        f = open(path)
        return f

    def parkTime(self, alltime):
        try:
            if alltime.startswith('@'):
                time_tuple = []
                alltime = alltime.split('!')
                num = len(alltime)
                for i in xrange(num):
                    a = tuple(alltime[i].split(','))
                    time_tuple.append(a)
                time_tuple = tuple(time_tuple)
                return time_tuple
            time1 = alltime.split(',')[0]
            time2 = alltime.split(',')[1]
            time1 = time.strptime(time1, "%Y%m%d%H%M%S")
            time2 = time.strptime(time2, "%Y%m%d%H%M%S")
            time_tuple = (
                (time1.tm_year,
                 time1.tm_mon,
                 time1.tm_mday,
                 time1.tm_hour,
                 time1.tm_min,
                 time1.tm_sec),
                (time2.tm_year,
                 time2.tm_mon,
                 time2.tm_mday,
                 time2.tm_hour,
                 time2.tm_min,
                 time2.tm_sec)
            )
            return time_tuple
        except ValueError, e:
            pass

    def t2h(self, t):
        objhash = {}
        RESUL = {}
        deschash = {}
        for tupledata in RESUL:
            objhash[tupledata[0]] = tupledata[1]
            deschash[tupledata[0]] = tupledata[2]
        if objhash.has_key(t):
            inputobj = objhash[t]
            message = deschash[t]
        else:
            inputobj = 0
            message = "输入的预期结果不正确，请从新输入"
        return inputobj, message

    def __getData(self, f):
        for line in f:
            self.num += 1
            if line != '\n' and not line.startswith("#"):
                try:
                    inputs = line.split('|')[0]
                    output = line.split('|')[1]
                    des = line.split('|')[2]
                    print line
                    parktime = line.split('|')[3]
                    yield inputs, output, des, self.parkTime(parktime)
                except IndexError:
                    print "数据输入格式不正确，请检查输入内容，报错提示%s:出错内容是第%d，内容为%s" % (IndexError, self.num, inputs)
                # Combined().openFile(path)
                # Combined().parkTime()

    def getData(self, f_path):
        klen = 0
        # act_klen = 0
        try:
            with open(f_path, 'rb') as f:
                import os
                case_file = os.path.split(f_path)[-1].split('.')[0]
                for line in f.readlines():
                    klen += 1
                    if not (line == '\n' or line == '\n\r' or line == '\r' or line == '\r\n'):
                        if not line.startswith("#"):
                            # act_klen += 1
                            inputs = line.split('|')[0]
                            output = line.split('|')[1]
                            des = line.split('|')[2]
                            linput = inputs.split(',')
                            yield linput, output, des, klen, case_file
        except Exception, e:
            print 'read case error: {}'.format(repr(e))