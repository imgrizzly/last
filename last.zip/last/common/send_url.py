# -*- coding: utf-8 -*-
'''
Created on 2019年03月10日
@author: yulei
'''
import json
import urllib, urllib2
import time
import hashlib
from Cityplatform.last.configmore.configset import *
from judgedata import *
json.encoder.FLOAT_REPR = lambda x: format(x, '.2f')


class SendUrl(object):
    def __init__(self, url, testmodule):
        self.url = url
        self.testmodule = testmodule

    def get_even(self, testmodule, linput):  # 此处linput为除去testmodul的data部分
        '''执行接口调用'''
        if testmodule in TESTOBJ.keys():
            reqdatas = self.serializeMessage(testmodule, linput, MERCHANT_KEY)
            if testmodule in GET:
                jsonresult = self.Connection(data=reqdatas)
            else:
                jsonresult = self.Connection(mode='POST', data=reqdatas)
            return jsonresult
        else:
            print 'there is no testmodule {}'.format(testmodule)


    def _MD5Encode(self, data, Enckey, time_stamp):
        '''count sign_code by md5'''
        try:
            if not isinstance(time_stamp, basestring):
                time_stamp = str(time_stamp)
            m = hashlib.md5()
            # print ''.join([data,Enckey,time_stamp])
            m.update(''.join([data, Enckey, time_stamp]))
            MD5Encode = m.hexdigest()
            # print data,Enckey,time_stamp
            # print MD5Encode
            return MD5Encode
        except TypeError:
            import sys
            s = sys.exc_info()
            print "Error '%s' happened on line %d" % (s[1], s[2].tb_lineno)
            sys.exit()

    def _creationDate(self, flag='time_stamp', data=None):
        '''
        @keyword flag:
        flag等于'time_stamp'表示返回时间戳要求格式;
        flag等于'time'表示返回需要请求字段的时间格式;
        '''
        if flag == 'time_stamp':
            time_stamp = time.strftime("%Y%m%d%H%M%S", time.localtime())
        # if flag == 'time':
        else:
            time_stamp = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        return time_stamp

    def _returnkey(self, key):
        return isinstance(key, tuple)

    def _removeSpecialCharacter(self, removedata):
        '''remove special characters from data'''
        sc = [' ', '\n', '\t', '\r\n', '']
        if isinstance(removedata, basestring):
            for x in sc:
                removedata = removedata.replace(x, '')
            return removedata

    def structureData(self, data):
        '''make up dictdata from testcase'''
        keys = TESTOBJ[self.testmodule]
        # print keys,data
        i = 0
        dictdata = {}
        klist = []
        vlist = []
        for key in keys:
            # if data[i] == 'None' or data[i] == 'null':
            #     i += 1
            #     continue
            if isinstance(key, basestring):
                dictdata[key] = data[i]
                # jsondata = json.dumps(dictdata, separators=(',', ':'))
                # jsondata = self._removeSpecialCharacter(jsondata)
                # dictdata = json.loads(jsondata)
                if key in time_list:
                    # m = key
                    # n = data[i]
                    # dictdata[key] = data[i]
                    klist.append(key)
                    vlist.append(data[i])
                i += 1
        # try:
        #     dictdata[m] = n
        # except:
        #     pass
        # finally:
        jsondata = json.dumps(dictdata, separators=(',', ':'))
        jsondata = self._removeSpecialCharacter(jsondata)
        dictdata = json.loads(jsondata)
        for i in range(len(klist)):
            dictdata[klist[i]] = vlist[i]
        # print dictdata
        return dictdata

    def serializeMessage(self, testmodule, data, MERCHANT_KEY):
        '''make up requestdata  by urlencode'''
        try:
            dictdata = self.structureData(data)
            if dictdata:
                time_stamp = str(self._creationDate())
                dictdata = judge_data(dictdata)
                # print dictdata
                jsondata = json.dumps(dictdata, separators=(',', ':'))
                jsondata = urllib.quote(jsondata, safe=':/')
                key = self._MD5Encode(jsondata, MERCHANT_KEY, time_stamp)
                key = key.upper()
                reqdata = {}
                # reqdata["version"]='1.0.0'
                reqdata["data"] = jsondata
                reqdata["sign"] = key
                reqdata["merchant_no"] = MERCHANT_NUM
                reqdata["time_stamp"] = time_stamp
                return reqdata
        except Exception, e:
            print repr(e)

    def geturl(self):
        url = '/'.join(self.testmodule.split('@'))
        return ''.join("%s%s" % (self.url, url))

    def Connection(self, mode='GET', data=''):
        '''connect using formed_requestdata by their method'''
        header_content = {"Content-Type": "application/json", "charset": "utf-8"}
        print json.dumps(data, separators=(',', ':'))
        if mode == 'POST':
            req = urllib2.Request(self.geturl(), data=json.dumps(data, separators=(',', ':')), headers=header_content)
            print self.geturl()
            response = urllib2.urlopen(req)
        else:
            data['data'] = urllib.unquote(data['data'])
            data = urllib.urlencode(data)
            reqdata = ''.join("%s%s%s" % (self.geturl(), '?', data))
            print reqdata
            req = urllib2.Request(reqdata, headers=header_content)
            response = urllib2.urlopen(req)
        result = response.read()
        # print '------------------reult'
        # print result
        response.close()
        jsonresult = json.loads(result)
        return jsonresult