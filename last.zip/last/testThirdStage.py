# -*- coding: utf-8 -*-"
'''
Created on 2019年3月10日

@author: yulei
'''
import sys, os
import dubbo_telnet
import nose

reload(sys)
sys.setdefaultencoding('utf-8')

from nose.tools import assert_equal
sys.path.append(os.path.join(os.path.split(os.path.realpath(__file__))[0], 'common'))
sys.path.append(os.path.join(os.path.split(os.path.realpath(__file__))[0], 'configmore'))
from readcase import Combined
from config import *
from send_url import *
from configset import *
# from Cityplatform.last.common.readcase import Combined
# from Cityplatform.last.config import Config
# from Cityplatform.last.common.send_url import *
# from Cityplatform.last.configmore.configset import *
from collections import OrderedDict

# f_path = os.path.split(os.path.realpath(__file__))[0]
rc = Combined()
config_obj = Config()


def coondoubble_data(host, port, interface, method, param):
    try:
        conn = dubbo_telnet.connect(host, port)
        conn.set_connect_timeout(10)
        conn.set_encoding('utf-8')
        for i in range(len(param)):
            if param[i].find('{') == 0:
                param[i] = eval(param[i])
                if param[i].has_key('getTime'):
                    if param[i]['getTime'] == 'time':
                        param[i]['getTime'] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
            elif param[i].find('[') == 0:
                param[i] = json.loads(param[i], object_pairs_hook=OrderedDict, encoding='utf-8')
        params = json.dumps(param)[1:-1]
        # conn.invoke(interface, method, params)
        command = 'invoke %s.%s(%s)' % (interface, method, params)
        print command
        # result = conn.do(command)
        result = conn.invoke(interface, method, params)
        return result
    except Exception, e:
        print e
        return e


def setup():
    """setup_func test fixtures"""
    pass
    # print 'start'


def teardown():
    """tear down test fixtures"""
    pass
    # print 'done'


def test_Evens():
    for filename in os.listdir(case_path):
        if filename.startswith('case'):
            path = os.path.join(case_path, '{}'.format(filename))
            for linput, output, des, klen, case_file in rc.getData(path):
                yield check_even, linput, output, des, klen, case_file


def check_even(linput, output, des, klen, case_file):
    try:
        if linput[0] == 'dubbo':
            host = '10.105.23.75'
            # host = '10.105.23.101'
            # host = '10.105.23.102'
            port = linput[1]
            interface = linput[2]
            method = linput[3]
            param = linput[4].replace('&', ',').split('>')
            # param = json.dumps(','.join(param), ensure_ascii=False)
            jsonresult = coondoubble_data(host, port, interface, method, param)
        else:
            # url = 'http://biz.cityplatform.qa.etcp.cn/'  # 测试环境地址
            url = 'http://10.100.24.66:8085/'  # dev环境地址
            # url = 'http://access-qa.sparkingcd.com:8085/'  #qa环境地址
            # url = 'http://10.105.23.114:8102/'  #qa环境支付地址
            # url = 'http://paygw.cityplatform.qa.etcp.cn/'  # 支付测试地址
            # url = 'http://10.105.23.101:8081/'
            # url = 'http://biz-cd.etcp.cn/'     #生产环境地址
            # url = 'http://paygw-cd.etcp.cn/'      # 支付生产地址
            # url = 'http://10.103.23.95:18887/'  # 服务商地址
            # url = 'http://127.0.0.1:9191/'  # 本地地址
            testmodule = linput[0]
            sendurl = SendUrl(url, testmodule)
            jsonresult = sendurl.get_even(testmodule, linput[1:])
        if jsonresult:
            print json.dumps(jsonresult).decode('unicode_escape')
            print case_file, str(klen) + ' des:', des
            print '-----------------------------------'
            if str(jsonresult['message'].encode('utf-8')) != output:
                config_obj.set_value(case_file, str(jsonresult['message'].encode('utf-8')), output)
            # if testmodule == 'parking/lot/lotin':
            #     config_obj.set_value('thirdLotNO_old', 'parkingLotNo', jsonresult['data']['parkingLotNo'])
            #调试用equal，回归用not_equal
            assert_equal(str(jsonresult['message'].encode('utf-8')), 1,
                         msg="{0} {1} output: {2}".format(case_file, klen, output))
            # assert_not_equal(jsonresult['code'], 0,
            #              msg="{0} {1} error: {2}".format(case_file, klen, output))
        else:
            assert_equal(0, 1, msg='None result!')
    except ValueError, e:
        print e


if __name__ == '__main__':
    nose.main()